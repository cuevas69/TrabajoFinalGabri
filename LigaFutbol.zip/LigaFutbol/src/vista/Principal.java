package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bbdd.Conexion;
import controlador.Central;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Principal extends JFrame {
	
	private JPanel contentPane;
	private JTextField inputNombre;
	private JTextField inputPosicion;
	private JTextField inputEquipo;

	public Principal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(51, 29, 78, 22);
		panel.add(lblNombre);
		
		inputNombre = new JTextField();
		inputNombre.setBounds(108, 30, 86, 20);
		panel.add(inputNombre);
		inputNombre.setColumns(10);
		
		JLabel lblPosicion = new JLabel("Posicion:");
		lblPosicion.setBounds(51, 73, 78, 22);
		panel.add(lblPosicion);
		
		inputPosicion = new JTextField();
		inputPosicion.setColumns(10);
		inputPosicion.setBounds(108, 74, 86, 20);
		panel.add(inputPosicion);
		
		JLabel lblEquipo = new JLabel("Equipo:");
		lblEquipo.setBounds(51, 116, 78, 22);
		panel.add(lblEquipo);
		
		inputEquipo = new JTextField();
		inputEquipo.setColumns(10);
		inputEquipo.setBounds(108, 117, 86, 20);
		panel.add(inputEquipo);
		
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setBounds(203, 191, 89, 23);
		panel.add(btnBuscar);
		
		JButton btnTodos = new JButton("Ver todos");
		btnTodos.setBounds(51, 191, 89, 23);
		panel.add(btnTodos);
		
		/* Acciones */
		
		btnTodos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Central().verTodos();
			}
		});
		
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nombre = inputNombre.getText();
				String posicion = inputPosicion.getText();
				String equipo = inputEquipo.getText();
				new Central().crearJugador(nombre, posicion, equipo);
			}
		});
	}
}
