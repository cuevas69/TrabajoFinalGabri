package controlador;

import java.util.ArrayList;

import javax.swing.JOptionPane;

import beans.Jugador;
import modelo.Jugadores;
import vista.Principal;
import vista.VistaJugador;

public class Central {
	
	public void crearJugador(String nombre, String posicion, String equipo) {

		Jugador jugadorRecogido = new Jugadores().recogerJugador(nombre, posicion, equipo);
		if(jugadorRecogido != null) {			
			JOptionPane.showMessageDialog(null, "Hola "+jugadorRecogido.getNombre());
			/* Llamada a la otra ventana */
			new vista.VistaJugador(jugadorRecogido);
		}else {
			int opcion = JOptionPane.showConfirmDialog(null, "No se ha encontrado jugador\n Desea guardarlo?");
			if(opcion == 0) {
				
				Jugador jugador = new Jugador(99,nombre,69,posicion,equipo);
				new Jugadores().insertarJugador(jugador);
			}
			
		}
	}
		
	public void verTodos() {
		/* Cargar los datos */
		ArrayList<Jugador> jugadores = new modelo.Jugadores().recogerTodosJugadores();
		/* Abrir ventana ver todos */
		new vista.Tabla(jugadores);
	}
	
}

