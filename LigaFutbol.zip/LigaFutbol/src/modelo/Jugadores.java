package modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bbdd.Conexion;
import beans.Jugador;

public class Jugadores {
	
	public void insertarJugador(Jugador jugador) {
		/* metodo para insertar jugador */
		int id = jugador.getId();
		String nombre = jugador.getNombre();
		int dorsal = jugador.getDorsal();
		String posicion = jugador.getPosicion();
		String equipo = jugador.getEquipo();

		Conexion.ejecutarUpdate("INSERT INTO jugadores (id, nombre, dorsal, posicion, equipo) VALUES ('"+id+"', '"+nombre+"', '"+dorsal+"', '"+posicion+"', '"+equipo+"');");
	}
	
	public Jugador recogerJugador(String nombreJugador, String posicionJugador, String equipoJugador) {
		/* metodo para recoger jugador */
		ResultSet resultado = Conexion.ejecutarSentencia("SELECT * FROM jugadores WHERE nombre='"+nombreJugador+"' AND posicion='"+posicionJugador+"' AND equipo='"+equipoJugador+"';");
		try {
			if(resultado.next()) {
				int id = resultado.getInt("id");
				String nombre = resultado.getString("nombre");
				int dorsal = resultado.getInt("dorsal");
		        String posicion = resultado.getString("posicion");
		        String equipo = resultado.getString("equipo");
				Jugador jugadorRecogido = new Jugador(id, nombre, dorsal, posicion, equipo);
				return jugadorRecogido;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		/* Transformacion */
		return null;
	}
	
	public ArrayList<Jugador> recogerTodosJugadores(){
		/* metodo para recoger todos los datos */
		ArrayList<Jugador> jugadores = new ArrayList<Jugador>();
		ResultSet resultado = Conexion.ejecutarSentencia("SELECT * FROM jugadores;");
		try {
			while(resultado.next()) {
				int id = resultado.getInt("id");
				String nombre = resultado.getString("nombre");
				int dorsal = resultado.getInt("dorsal");
		        String posicion = resultado.getString("posicion");
		        String equipo = resultado.getString("equipo");
				jugadores.add(new Jugador(id, nombre, dorsal, posicion, equipo));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return jugadores;
	}
}

