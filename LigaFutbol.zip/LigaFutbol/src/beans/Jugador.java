package beans;

public class Jugador {
	/* valores de la bbdd */
	private int id;  
	private String nombre;
	private int dorsal;
    private String posicion;
    private String equipo;
    
    public Jugador() {
    	/* constructor vac�o */
    }
	public Jugador(int id, String nombre, int dorsal, String posicion, String equipo) {
		/* constructor declarado */
		this.id = id;
		this.nombre = nombre;
		this.dorsal = dorsal;
		this.posicion = posicion;
		this.equipo = equipo;
	}
	
	/* getters y setters */
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getDorsal() {
		return dorsal;
	}
	public void setDorsal(int dorsal) {
		this.dorsal = dorsal;
	}
	public String getPosicion() {
		return posicion;
	}
	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}
	public String getEquipo() {
		return equipo;
	}
	public void setEquipo(String equipo) {
		this.equipo = equipo;
	}
}