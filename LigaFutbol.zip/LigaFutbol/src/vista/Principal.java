package vista;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import bbdd.Conexion;
import controlador.Central;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.Toolkit;

public class Principal extends JFrame {
	/* paneles y inputs */
	private JPanel contentPane;
	private JTextField inputNombre;
	private JTextField inputPosicion;
	private JTextField inputEquipo;

	public Principal() {
		/* agregar paneles e imagenes de fondo */
		setIconImage(Toolkit.getDefaultToolkit().getImage(Principal.class.getResource("/imagen/icono.jpg")));
		setTitle("LigaFutbol");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		/* agregar JLabel "" con formatos */
		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNombre.setForeground(Color.YELLOW);
		lblNombre.setBounds(51, 29, 78, 22);
		panel.add(lblNombre);
		
		inputNombre = new JTextField();
		inputNombre.setBounds(108, 30, 86, 20);
		panel.add(inputNombre);
		inputNombre.setColumns(10);
		
		JLabel lblPosicion = new JLabel("Posicion:");
		lblPosicion.setForeground(Color.YELLOW);
		lblPosicion.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPosicion.setBounds(51, 73, 78, 22);
		panel.add(lblPosicion);
		
		inputPosicion = new JTextField();
		inputPosicion.setBounds(108, 74, 86, 20);
		inputPosicion.setColumns(10);
		panel.add(inputPosicion);
		
		JLabel lblEquipo = new JLabel("Equipo:");
		lblEquipo.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblEquipo.setForeground(Color.YELLOW);
		lblEquipo.setBounds(51, 116, 78, 22);
		panel.add(lblEquipo);
		
		inputEquipo = new JTextField();
		inputEquipo.setBounds(108, 117, 86, 20);
		inputEquipo.setColumns(10);
		panel.add(inputEquipo);
		
		/* Agregar botones para acciones */
		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.setBounds(203, 191, 89, 23);
		panel.add(btnBuscar);
		
		JButton btnTodos = new JButton("Ver todos");
		btnTodos.setBounds(51, 191, 89, 23);
		panel.add(btnTodos);
		
		JLabel lblFondo = new JLabel("");
		lblFondo.setIcon(new ImageIcon(Principal.class.getResource("/imagen/fondo1.jpg")));
		lblFondo.setBounds(0, 0, 424, 251);
		panel.add(lblFondo);
		
		/* Acciones que ejecutan el boton buscar y ver todos */
		
		btnTodos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Central().verTodos();
			}
		});
		
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String nombre = inputNombre.getText();
				String posicion = inputPosicion.getText();
				String equipo = inputEquipo.getText();
				new Central().crearJugador(nombre, posicion, equipo);
			}
		});
	}
}
