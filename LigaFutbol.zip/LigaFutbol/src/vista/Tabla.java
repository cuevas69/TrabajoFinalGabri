package vista;

import java.awt.BorderLayout;
import java.sql.Date;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;

import beans.Jugador;
import java.awt.Toolkit;

public class Tabla extends JFrame {

	private JPanel contentPane;
	private JTable table;

	public Tabla(ArrayList<Jugador> jugadores) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Tabla.class.getResource("/imagen/icono.jpg")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		/* Crear la tabla con su modelo */
		DefaultTableModel dtm = new DefaultTableModel();
		contentPane.setLayout(null);
		table = new JTable(dtm);
		table.setBounds(5, 5, 424, 251);
		contentPane.add(table);
		/* Crear las columnas */
		dtm.addColumn("Id");
		dtm.addColumn("Nombre");
		dtm.addColumn("Dorsal");
		dtm.addColumn("Posicion");
		dtm.addColumn("Equipo");
		/* Rellenar los datos con el array de jugadores */
		for(Jugador jugador : jugadores) {
			Object[] fila = new Object[5];
			fila[0] = jugador.getId();
			fila[1] = jugador.getNombre();
			fila[2] = jugador.getDorsal();
			fila[3] = jugador.getPosicion();
			fila[4] = jugador.getEquipo();
			dtm.addRow(fila);			
		}
		
		
		setVisible(true);
	}
}

