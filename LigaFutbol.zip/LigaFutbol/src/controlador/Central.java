package controlador;

import java.sql.Date;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import beans.Jugador;
import modelo.Jugadores;
import vista.Principal;

public class Central {
	
	public void crearJugador(String nombre) {

		Jugador jugadorRecogido = new Jugadores().recogerJugador(nombre);
		if(jugadorRecogido != null) {			
			JOptionPane.showMessageDialog(null, "Hola "+jugadorRecogido.getNombre());
			/* Llamada a la otra ventana */
			new vista.VistaJugador(jugadorRecogido);
		}else {
			int opcion = JOptionPane.showConfirmDialog(null, "No se ha encontrado jugador\n Desea guardarlo?");
			if(opcion == 0) {
				
				Jugador jugador = new Jugador(1,nombre,1,nombre,nombre);
				new Jugadores().insertarJugador(jugador);
			}
			
		}
	}
		
	public void crearPosicion(String posicion) {

		Jugador jugadorRecogido = new Jugadores().recogerJugador(posicion);
		if(jugadorRecogido != null) {			
			JOptionPane.showMessageDialog(null, "Juega de "+jugadorRecogido.getPosicion());
			/* Llamada a la otra ventana */
			new vista.VistaJugador(jugadorRecogido);
		}else {
			int opcion = JOptionPane.showConfirmDialog(null, "No se ha encontrado jugador\n Desea guardarlo?");
			if(opcion == 0) {
					
				Jugador jugador = new Jugador(1,posicion,1,posicion,posicion);
				new Jugadores().insertarJugador(jugador);
			}
				
		}	
		
	}
	
	public void crearEquipo(String equipo) {

		Jugador jugadorRecogido = new Jugadores().recogerJugador(equipo);
		if(jugadorRecogido != null) {			
			JOptionPane.showMessageDialog(null, "En el club: "+jugadorRecogido.getEquipo());
			/* Llamada a la otra ventana */
			new vista.VistaJugador(jugadorRecogido);
		}else {
			int opcion = JOptionPane.showConfirmDialog(null, "No se ha encontrado jugador\n Desea guardarlo?");
			if(opcion == 0) {
					
				Jugador jugador = new Jugador(1,equipo,1,equipo,equipo);
				new Jugadores().insertarJugador(jugador);
			}
				
		}	
		
	}
	
	public void verTodos() {
		/* Cargar los datos */
		ArrayList<Jugador> jugadores = new modelo.Jugadores().recogerTodosJugadores();
		/* Abrir ventana ver todos */
		new vista.Tabla(jugadores);
	}
	
}

